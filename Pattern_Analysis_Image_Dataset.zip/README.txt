PATTERN ANALYSIS / MACHINE LEARNING PRACTICAL DATASET

Dataset structure:
  classes/circle/    20 images
  classes/square/    20 images
  classes/triangle/  20 images
  classes/star/      20 images
  unlabeled_examples/ 12 renamed examples for semi-supervised demonstrations

Total labeled images: 80
Image size: 160 x 160 pixels

The four labels are intentionally encoded by folder name. The images contain controlled variation in size, position, small rotation, color shade, noise and blur.

Use this same dataset for all practicals:
Q1 K-Means clustering
Q2 K-Medoids clustering
Q3 Gaussian Mixture Model
Q4 Supervised vs unsupervised learning
Q5 Bayesian classification
Q6 KNN classification
Q7 ANN classification
Q8 Semi-supervised classification
Q9 PCA, LDA, ICA and t-SNE dimensionality reduction
Q10 Complete pattern-recognition system

The supplied solution manual extracts HOG image features before applying the learning algorithms.
